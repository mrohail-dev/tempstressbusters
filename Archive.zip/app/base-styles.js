import sc from '../config/styles';

export default {
	text: {
		color: sc.textColor,
	},
}
